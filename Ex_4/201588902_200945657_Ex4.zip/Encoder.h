#ifndef _ENCODER__H_
#define _ENCODER__H_

#include <vector>
#include <string>
using namespace std;

class Encoder
{
public:
  static void encode(const string& imagesString, const string& videoOutput);
};

#endif //_ENCODER__H_
